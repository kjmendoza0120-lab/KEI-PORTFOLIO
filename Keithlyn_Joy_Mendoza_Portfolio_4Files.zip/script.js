// Interactive functionality for Keithlyn Joy Mendoza's Portfolio

document.addEventListener('DOMContentLoaded', () => {
  const milestoneDetails = {
    vision: {
      tag: '01 / PROJECT MILESTONE · COMPUTER VISION',
      title: 'ROBOFLOW IMAGE CLASSIFICATION',
      issuer: 'Keithlyn Joy Mendoza · 1st Year BSIT, Mindoro State University',
      body: 'Built and tested a dog-and-cat image classification workflow in Roboflow with dataset splitting (70-30-10), dataset version generation, model testing, and a voice-over walkthrough.',
      skills: ['Roboflow', '70-30-10 Split', 'Dataset Versioning', 'Model Testing']
    },
    web: {
      tag: '02 / PROJECT MILESTONE · WEB DEVELOPMENT',
      title: 'HTML & CSS PORTFOLIO BUILDS',
      issuer: 'Keithlyn Joy Mendoza · Visual Studio Code Projects',
      body: 'Designed and structured portfolio web pages using HTML and external CSS stylesheets with attention to layout polish, typography, and visual styling.',
      skills: ['HTML5', 'CSS3', 'Visual Studio Code', 'Layout Design']
    }
  };

  const modal = document.getElementById('certModal');
  const modalTag = document.getElementById('modalTag');
  const modalTitle = document.getElementById('modalTitle');
  const modalIssuer = document.getElementById('modalIssuer');
  const modalBody = document.getElementById('modalBody');
  const modalSkills = document.getElementById('modalSkills');
  const closeModalBtn = document.getElementById('closeModalBtn');

  document.querySelectorAll('.cert-card').forEach((card) => {
    card.addEventListener('click', () => {
      const key = card.getAttribute('data-cert');
      const data = milestoneDetails[key];
      if (!data) return;

      modalTag.textContent = data.tag;
      modalTitle.textContent = data.title;
      modalIssuer.textContent = data.issuer;
      modalBody.textContent = data.body;

      modalSkills.innerHTML = '';
      data.skills.forEach((skill) => {
        const badge = document.createElement('span');
        badge.textContent = skill;
        modalSkills.appendChild(badge);
      });

      modal.classList.add('open');
      modal.setAttribute('aria-hidden', 'false');
    });
  });

  function closeModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
  }

  closeModalBtn.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      closeModal();
    }
  });

  const copyNameBtn = document.getElementById('copyNameBtn');
  if (copyNameBtn) {
    copyNameBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText('Keithlyn Joy Mendoza');
        copyNameBtn.textContent = 'Copied!';
        setTimeout(() => {
          copyNameBtn.textContent = 'Copy Name';
        }, 2000);
      } catch (err) {
        copyNameBtn.textContent = 'Ready';
      }
    });
  }

  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-links a');

  window.addEventListener('scroll', () => {
    let current = '';
    sections.forEach((section) => {
      const sectionTop = section.offsetTop - 120;
      if (window.scrollY >= sectionTop) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach((link) => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  });
});
